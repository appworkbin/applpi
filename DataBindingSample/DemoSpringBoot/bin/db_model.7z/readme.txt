										registration
	* getCustomerNumber(String accountNumber)									1) validate credit card account number
	if (customerNumber != null)									2) create NEW username/password
		create record in CONSUMER_REGISTRATION table								3) validate OTP
			customerNumber			"0000183837173"				
			terminalResourceCode			"12983949-jajaijg-8938hw"				mVisa Onboarding
			status			VALIDATED				1) Link accounts, Set primary account
			token			"465615C0-26FC-4807-D060-5FEFCEA257B5"				2) Set primary account
		return terminalResourceCode								3) Create mPIN
			registration-token							
			validated-status message							
	else return error ACCOUNT_NOT_RECOGNIZED									
=====================										
	* check if terminalResourceCode matches in the CONSUMER_REGISTRATION table									
	* check if registration-token matches									
	* create random-salt:   8509A816-4EB8-A4A8-2E84-1340F9F6A617 > toHEX									
	* hash the password with the salt 									
	* string[]  getConsumerAccounts(String customerNumber) from HOST last 4 digits only									
	* string[] getConsumerName(String customerNumber) from HOST									
	* if all success create the User in the user table									
	BEGIN TRX	insert into USERS (username, consumer_profile, create date, create user) 								
		      values ('v_username', 'consumer', 'disabled', sysdate, system)								
		insert into USER_CREDENTIALS ('hash password', 'salt'								
		insert into CONSUMER_PROFILE ('customer_number', 'customer_name'								
		insert into CONSUMER_ACCOUNTS ('consumer_last4digits')								
	END TRX	insert into CONSUMER_DEVICE ('consumer_device_id')								
	generateUserVerificationCode()									
	* generate verification_token									
	* update the CONSUMER_REGGISTRATION									
		update (verification_token, new timestamp, status=registered_inactive)								
	* generate verification code									
	* send verification code thru SMS/email									
	* insert in USERS ('hashed verification code', 'verification_token')									
										
	return verification_token									
		status=activation_required								
										
============================										
										
	*check the device-code, resource-serial-number									
	*check the token - if match, if not expired									
	checkUserVerificationCode()									
	* check if the verification code matches the hashed verification code									
	* if success									
		update USERS ('enabled = true', new_token)								
		update CONSUMER_REGISTRATION (new_token, timestamp, status=registered_active)								
										
	return									
		status=mvisa_onboarding_required								
										
===========================										
	* client needs to get oauth access_token here using username/password									
===========================										
	* check the device-code, resource-seriall-number									
	getConsumerAccounts()									
	* request to retrieve the list of consumer accounts									
										
	return the list of consumer accounts									
										
====================================										
	* check the device-code, resource-serial-number									
										
	setConsumerMVisaAccount()									
	* check if at least one account is linked, check if only one is set default									
	* update CONSUMER_ACCOUNTS( linked_cards, primary_cards)									
										
	* update CONSUMER_REGISTRATION (null_token, timestamp, stamp=mvisa_account_set									
										
	return									
		status=mpin_setting_required								
										
========================================										
	* check the device-code, resource-serial-number									
	setConsumerMPin()									
	* update USER_CREDENTIALS (hashed_mPin, salt)									
	* update CONSUMER_REGISTRATION (null_token, timestamp, status=mpin_set)									
										
	return	status=mpin_success								
										
===========================================										
										
	getConsumerDashboardInfo()									
										
	return Latest transactions , limit=5									
	             latest transaction_date									
	             Consumer name									
